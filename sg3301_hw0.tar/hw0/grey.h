/*************************************************************************
    > File Name: grey.h
    > Author: Gu Shenlong
    > Mail: blackhero98@gmail.com
    > Created Time: Wed Feb  3 14:22:11 2016
 ************************************************************************/
#include <iostream>
#include <ImfRgbaFile.h>
#include <ImathBox.h>
#include <ImfArray.h>
using namespace std;
using namespace Imf;
using namespace Imath; 
using namespace Imf_2_2;

